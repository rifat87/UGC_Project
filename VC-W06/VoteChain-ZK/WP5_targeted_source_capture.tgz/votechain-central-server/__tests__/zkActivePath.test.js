import test from 'node:test'
import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'

const activeBackendFiles = [
  '../controllers/voteController.js',
  '../controllers/fingerprintController.js',
  '../controllers/voterController.js',
  '../services/zk/proofCore.js',
  '../services/zk/proofService.js',
]

const activeFrontendFiles = [
  '../../votechain-frontend-ts/src/hooks/useContract.ts',
  '../../votechain-frontend-ts/src/components/Biometric/VerificationModal.tsx',
  '../../votechain-frontend-ts/src/components/Voter/VoteCasting.tsx',
  '../../votechain-frontend-ts/src/components/Admin/RegisterVoter.tsx',
  '../../votechain-frontend-ts/src/services/api.ts',
]

test('active biometric and blockchain ZK path does not use voterHash or encryptedSalt', () => {
  for (const relative of [...activeBackendFiles, ...activeFrontendFiles]) {
    const source = readFileSync(new URL(relative, import.meta.url), 'utf8')
    assert.doesNotMatch(source, /voterHash|encryptedSalt/, `legacy identity primitive remains active in ${relative}`)
  }
})

test('active voter flow sends candidateId plus Semaphore proof and keeps wallet identity separate', () => {
  const hook = readFileSync(new URL('../../votechain-frontend-ts/src/hooks/useContract.ts', import.meta.url), 'utf8')
  assert.match(hook, /castVote\(candidateId,\s*proof\)/)
  assert.match(hook, /registerVoterCommitment\(BigInt\(identityCommitment\)\)/)
  assert.doesNotMatch(hook, /msg\.sender|authorizedVoteWallet|onlyVoteWallet/)
})

test('backend gates ZK enrollment to Registration and proof preparation to Active valid candidates', () => {
  const voterController = readFileSync(new URL('../controllers/voterController.js', import.meta.url), 'utf8')
  const proofService = readFileSync(new URL('../services/zk/proofService.js', import.meta.url), 'utf8')

  assert.match(voterController, /getElectionState\(\)/)
  assert.match(voterController, /electionState !== 0/)
  assert.match(proofService, /getElectionState\(\)/)
  assert.match(proofService, /Number\(electionState\) !== 1/)
  assert.match(proofService, /contract\.candidates\(BigInt\(normalizedCandidateId\)\)/)
  assert.match(proofService, /Selected candidate is not registered on-chain/)
})
