import Candidate from '../models/Candidate.js'
import { getContract } from '../utils/contract.js'
import { buildPublicElectionData } from '../services/electionDataService.js'

const getElectionData = async (_req, res) => {
  try {
    const candidateRecords = await Candidate.find({ candidateId: { $exists: true } }).sort({ candidateId: 1 }).lean()
    const data = await buildPublicElectionData({ candidateRecords, contract: getContract() })
    return res.json({ success: true, data })
  } catch (error) {
    console.error('Error fetching public election data:', error.message)
    return res.status(500).json({ success: false, message: 'Failed to fetch election data' })
  }
}

export default { getElectionData }
