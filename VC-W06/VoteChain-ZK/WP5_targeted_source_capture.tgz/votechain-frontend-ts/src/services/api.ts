import { apiUrl } from "@/config/api"

export type ElectionState = "Registration" | "Active" | "Ended"

export interface PublicCandidate {
  candidateId: number
  name: string
  party: string
  location: string
  voteCount: number
}

export interface PublicElectionData {
  electionState: ElectionState
  candidateCount: number
  candidates: PublicCandidate[]
}

interface ApiEnvelope<T> {
  success: boolean
  data?: T
  message?: string
  errors?: string[]
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(apiUrl(path), init)
  const payload = (await response.json()) as ApiEnvelope<T>

  if (!response.ok || payload.success === false) {
    const detail = payload.errors?.join(", ") || payload.message || `Request failed with ${response.status}`
    throw new Error(detail)
  }

  if (payload.data === undefined) {
    throw new Error("API response did not contain data")
  }

  return payload.data
}

export async function getPublicElectionData() {
  return request<PublicElectionData>("/api/elections/public/election-data")
}

export interface CandidateMetadataInput {
  nationalId: string
  name: string
  party: string
  location: string
  age: number
}

export interface CandidateAdminRecord {
  id: string
  candidateId: number
  name: string
  party: string
  location: string
  age: number
  registrationStatus: "pending" | "registered" | "failed"
}

export async function createCandidateMetadata(metadata: CandidateMetadataInput) {
  return request<CandidateAdminRecord>("/api/candidates/register", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(metadata),
  })
}

export async function updateCandidateRegistrationStatus(
  candidateId: number,
  registrationStatus: "pending" | "registered" | "failed",
) {
  return request<{ candidateId: number; registrationStatus: string }>(
    `/api/candidates/${candidateId}/registration-status`,
    {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ registrationStatus }),
    },
  )
}

export interface CreateVoterInput {
  nationalId: string
  name: string
  dateOfBirth: string
  location: string
}

export interface VoterCreationResult {
  identityCommitment: string
}

export interface SemaphoreProofPayload {
  merkleTreeDepth: number
  merkleTreeRoot: string
  nullifier: string
  message: string
  scope: string
  points: [string, string, string, string, string, string, string, string]
}

export interface ZkVotePreparation {
  candidateId: number
  electionId: string
  proof: SemaphoreProofPayload
}

export async function createVoter(input: CreateVoterInput) {
  const response = await fetch(apiUrl("/api/voters"), {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(input),
  })
  const payload = await response.json()

  if (!response.ok || !payload.success) throw new Error(payload.message || "Failed to create voter ZK enrollment")
  const identityCommitment = payload.data?.identityCommitment || payload.identityCommitment
  if (!identityCommitment) throw new Error("Identity commitment was not returned from backend")
  return { identityCommitment: String(identityCommitment) } as VoterCreationResult
}

export async function updateVoterZkRegistrationStatus(
  identityCommitment: string,
  registrationStatus: "registered" | "failed",
  transactionHash?: string,
) {
  const response = await fetch(apiUrl("/api/voters/zk-registration-status"), {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ identityCommitment, registrationStatus, transactionHash }),
  })
  const payload = await response.json()
  if (!response.ok || !payload.success) throw new Error(payload.message || "Failed to reconcile voter commitment registration")
  return payload.data as { identityCommitment: string; registrationStatus: string; groupIndex: number | null }
}

export async function prepareZkVote(path: string, candidateId: number) {
  const response = await fetch(apiUrl(path), {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ candidateId }),
  })
  const payload = await response.json()
  if (!response.ok || !payload.success) throw new Error(payload.message || "Biometric verification or proof generation failed")
  const data = payload.data || payload
  if (!data?.proof) throw new Error("Anonymous eligibility proof was not returned")
  return data as ZkVotePreparation
}
